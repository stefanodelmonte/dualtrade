/*
 * ============================================
 * Ribbon — Ticker de criptomonedas
 * ============================================
 * 
 * Barra horizontal con scroll infinito que muestra
 * los pares de criptomonedas principales.
 * 
 * Se duplican los items para crear el efecto de
 * loop continuo con CSS animation.
 * 
 * ============================================
 */

"use client";

/* Lista de tokens a mostrar */
const tokens = [
  { symbol: "BTC", name: "Bitcoin" },
  { symbol: "ETH", name: "Ethereum" },
  { symbol: "SOL", name: "Solana" },
  { symbol: "BNB", name: "BNB" },
  { symbol: "ADA", name: "Cardano" },
  { symbol: "XRP", name: "Ripple" },
  { symbol: "AVAX", name: "Avalanche" },
  { symbol: "DOT", name: "Polkadot" },
];

export default function Ribbon() {
  /* Duplicar para loop infinito */
  const items = [...tokens, ...tokens];

  return (
    <div
      style={{
        overflow: "hidden",
        borderTop: "0.5px solid rgba(0,0,0,0.08)",
        borderBottom: "0.5px solid rgba(0,0,0,0.08)",
        padding: "0.85rem 0",
        background: "#ffffff",
      }}
    >
      {/* Track que se desplaza */}
      <div
        style={{
          display: "flex",
          gap: "3.5rem",
          width: "max-content",
          animation: "ribbon-slide 22s linear infinite",
        }}
      >
        {items.map((t, i) => (
          <span
            key={`${t.symbol}-${i}`}
            style={{
              fontSize: "0.78rem",
              fontWeight: 400,
              letterSpacing: "0.06em",
              color: "#1d1d1f",
              whiteSpace: "nowrap",
              display: "flex",
              alignItems: "center",
              gap: "0.4rem",
              opacity: 0.5,
            }}
          >
            {/* Simbolo en dorado y bold */}
            <strong style={{ color: "#b8962e", fontWeight: 700, opacity: 1 }}>
              {t.symbol}
            </strong>
            {t.name}
          </span>
        ))}
      </div>

      {/* Keyframes para el desplazamiento */}
      <style jsx>{`
        @keyframes ribbon-slide {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }
      `}</style>
    </div>
  );
}
