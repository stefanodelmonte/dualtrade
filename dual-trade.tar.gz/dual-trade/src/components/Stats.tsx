/*
 * ============================================
 * Stats — Seccion de estadisticas / resultados
 * ============================================
 * 
 * - 4 metricas principales (Win Rate, Operaciones, R:R, Meses)
 * - Los numeros se animan de 0 al valor final 
 *   cuando la seccion entra en el viewport
 * - Separadores verticales entre stats en desktop
 * - Stagger en la entrada de cada bloque
 * 
 * Los valores son PLACEHOLDER — cambiar por datos reales.
 * 
 * ============================================
 */

"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import Reveal from "./Reveal";

/* Definicion de cada estadistica */
interface StatDef {
  target: number;
  suffix: string;
  decimal?: boolean;
  label: string;
}

const stats: StatDef[] = [
  { target: 87, suffix: "%", label: "Win Rate" },
  { target: 320, suffix: "", label: "Operaciones cerradas" },
  { target: 3.2, suffix: "R", decimal: true, label: "Ratio medio R:R" },
  { target: 24, suffix: "", label: "Meses operando" },
];

/* Curva Apple */
const ease: [number, number, number, number] = [0, 0, 0.5, 1];

/*
 * Counter — Componente que anima un numero de 0 al target
 * Usa IntersectionObserver para detectar cuando es visible
 * y requestAnimationFrame para la animacion fluida.
 */
function Counter({
  target,
  suffix,
  decimal,
}: {
  target: number;
  suffix: string;
  decimal?: boolean;
}) {
  const [value, setValue] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const animated = useRef(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !animated.current) {
          animated.current = true;

          const duration = 1600; /* ms */
          const startTime = performance.now();

          function tick(now: number) {
            const progress = Math.min((now - startTime) / duration, 1);
            /* Ease-out quartica para desaceleracion natural */
            const eased = 1 - Math.pow(1 - progress, 4);
            setValue(
              decimal
                ? parseFloat((eased * target).toFixed(1))
                : Math.floor(eased * target)
            );
            if (progress < 1) requestAnimationFrame(tick);
          }

          requestAnimationFrame(tick);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, [target, decimal]);

  return (
    <span ref={ref}>
      {decimal ? value.toFixed(1) : value}
      {suffix && (
        <span style={{ color: "#b8962e" }}>{suffix}</span>
      )}
    </span>
  );
}

export default function Stats() {
  return (
    <section
      id="resultados"
      style={{
        padding: "clamp(5rem, 12vh, 9rem) clamp(1.5rem, 5vw, 4rem)",
        background: "#ffffff",
        borderTop: "0.5px solid rgba(0,0,0,0.06)",
      }}
    >
      {/* ── Titulo ── */}
      <div style={{ maxWidth: "980px", margin: "0 auto", textAlign: "center" }}>
        <Reveal>
          <h2
            style={{
              fontSize: "clamp(1.9rem, 4.5vw, 3.4rem)",
              fontWeight: 700,
              lineHeight: 1.08,
              letterSpacing: "-0.02em",
              color: "#1d1d1f",
            }}
          >
            Los numeros hablan.
          </h2>
          <h2
            style={{
              fontSize: "clamp(1.9rem, 4.5vw, 3.4rem)",
              fontWeight: 700,
              lineHeight: 1.08,
              letterSpacing: "-0.02em",
              color: "#1d1d1f",
              opacity: 0.35,
            }}
          >
            La consistencia convence.
          </h2>
        </Reveal>
      </div>

      {/* ── Grid de stats ── */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(4, 1fr)",
          maxWidth: "920px",
          margin: "3rem auto 0",
          textAlign: "center",
        }}
        className="stats-grid"
      >
        {stats.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 32 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.75, delay: i * 0.13, ease }}
            style={{
              padding: "2.5rem 1rem",
              position: "relative",
            }}
            className="stat-item"
          >
            {/* Separador vertical (excepto el primero) */}
            {i > 0 && (
              <div
                className="stat-divider"
                style={{
                  position: "absolute",
                  left: 0,
                  top: "20%",
                  height: "60%",
                  width: "0.5px",
                  background: "rgba(0,0,0,0.1)",
                }}
              />
            )}

            {/* Numero animado */}
            <div
              style={{
                fontSize: "clamp(2rem, 3.8vw, 3rem)",
                fontWeight: 700,
                lineHeight: 1,
                color: "#1d1d1f",
                marginBottom: "0.45rem",
              }}
            >
              <Counter
                target={s.target}
                suffix={s.suffix}
                decimal={s.decimal}
              />
            </div>

            {/* Label */}
            <div
              style={{
                fontSize: "0.78rem",
                fontWeight: 400,
                color: "#1d1d1f",
                opacity: 0.4,
                letterSpacing: "0.01em",
              }}
            >
              {s.label}
            </div>
          </motion.div>
        ))}
      </div>

      {/* ── Responsive: 2 columnas en movil ── */}
      <style jsx>{`
        @media (max-width: 768px) {
          .stats-grid {
            grid-template-columns: 1fr 1fr !important;
          }
          .stat-divider {
            display: none;
          }
        }
      `}</style>
    </section>
  );
}
