/*
 * ============================================
 * Approach — Seccion de enfoque / metodologia
 * ============================================
 * 
 * - Titulo a dos lineas (negro + dorado sutil)
 * - Linea decorativa dorada
 * - Parrafo descriptivo
 * - 3 tarjetas con el enfoque (analisis, riesgo, pares)
 * - Cards con hover: sube + linea dorada superior
 * - Animacion escalonada al entrar en viewport
 * 
 * ============================================
 */

"use client";

import { motion } from "framer-motion";
import Reveal from "./Reveal";

/* Datos de las tarjetas */
const cards = [
  {
    idx: "01",
    title: "Analisis Tecnico",
    body: "Lectura de precio, estructura de mercado y zonas de liquidez en temporalidades multiples.",
  },
  {
    idx: "02",
    title: "Gestion de Riesgo",
    body: "Posiciones calculadas al centimo. Ratio riesgo-beneficio favorable y drawdown bajo control.",
  },
  {
    idx: "03",
    title: "BTC / ETH / Alts",
    body: "Bitcoin y Ethereum como activos base. Operaciones selectivas en altcoins de alta capitalizacion.",
  },
];

/* Curva Apple */
const ease: [number, number, number, number] = [0, 0, 0.5, 1];

export default function Approach() {
  return (
    <section
      id="enfoque"
      style={{
        padding: "clamp(5rem, 12vh, 9rem) clamp(1.5rem, 5vw, 4rem)",
        background: "#ffffff",
        borderTop: "0.5px solid rgba(0,0,0,0.06)",
      }}
    >
      <div style={{ maxWidth: "980px", margin: "0 auto" }}>
        {/* ── Titulos ── */}
        <Reveal>
          <h2
            style={{
              fontSize: "clamp(1.9rem, 4.5vw, 3.4rem)",
              fontWeight: 700,
              lineHeight: 1.08,
              letterSpacing: "-0.02em",
              color: "#1d1d1f",
            }}
          >
            El metodo lo es todo.
          </h2>
          <h2
            style={{
              fontSize: "clamp(1.9rem, 4.5vw, 3.4rem)",
              fontWeight: 700,
              lineHeight: 1.08,
              letterSpacing: "-0.02em",
              color: "#1d1d1f",
              opacity: 0.35,
            }}
          >
            La emocion, nada.
          </h2>

          {/* Linea dorada decorativa */}
          <div
            style={{
              width: "32px",
              height: "1.5px",
              background: "#b8962e",
              borderRadius: "2px",
              margin: "1.6rem 0 1.8rem",
            }}
          />

          <p
            style={{
              fontSize: "clamp(0.92rem, 1.4vw, 1.1rem)",
              fontWeight: 300,
              lineHeight: 1.65,
              color: "#1d1d1f",
              opacity: 0.55,
              maxWidth: "560px",
            }}
          >
            Cada posicion se abre con un plan definido. Entrada, invalidacion,
            objetivo y tamano calculados antes de ejecutar. Sin impulsos, sin
            ruido, sin excusas.
          </p>
        </Reveal>

        {/* ── Grid de tarjetas ── */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap: "1.15rem",
            marginTop: "3.2rem",
          }}
        >
          {cards.map((c, i) => (
            <motion.div
              key={c.idx}
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.75, delay: i * 0.13, ease }}
              style={{
                background: "#ffffff",
                borderRadius: "18px",
                padding: "2.4rem 1.8rem 2.2rem",
                border: "1px solid rgba(0,0,0,0.06)",
                position: "relative",
                overflow: "hidden",
                cursor: "default",
                transition:
                  "transform 0.5s cubic-bezier(0.25,1,0.5,1), box-shadow 0.5s ease",
              }}
              whileHover={{
                y: -5,
                boxShadow: "0 10px 40px rgba(0,0,0,0.06)",
              }}
            >
              {/* Linea dorada superior (visible siempre sutilmente) */}
              <div
                style={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  right: 0,
                  height: "2px",
                  background:
                    "linear-gradient(90deg, transparent, #b8962e, transparent)",
                  opacity: 0.4,
                }}
              />

              {/* Numero */}
              <div
                style={{
                  fontSize: "2.6rem",
                  fontWeight: 700,
                  color: "#b8962e",
                  opacity: 0.3,
                  lineHeight: 1,
                  marginBottom: "1.4rem",
                }}
              >
                {c.idx}
              </div>

              {/* Titulo de la tarjeta */}
              <h3
                style={{
                  fontSize: "1.2rem",
                  fontWeight: 700,
                  letterSpacing: "-0.005em",
                  marginBottom: "0.55rem",
                  color: "#1d1d1f",
                }}
              >
                {c.title}
              </h3>

              {/* Descripcion */}
              <p
                style={{
                  fontSize: "0.88rem",
                  fontWeight: 300,
                  lineHeight: 1.6,
                  color: "#1d1d1f",
                  opacity: 0.5,
                }}
              >
                {c.body}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
