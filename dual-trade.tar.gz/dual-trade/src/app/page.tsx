/*
 * ============================================
 * Pagina principal — Dual Trade
 * ============================================
 * 
 * Compone todas las secciones en orden:
 * 
 * 1. Navbar    — navegacion fija con blur
 * 2. Hero      — titulo principal + CTAs
 * 3. Ribbon    — ticker de criptomonedas
 * 4. Approach  — metodologia / enfoque (3 cards)
 * 5. Chart     — grafico TradingView en vivo (dark)
 * 6. Philosophy — cita central
 * 7. Stats     — estadisticas animadas
 * 8. CTA       — llamada a la accion final
 * 9. Footer    — pie de pagina
 * 
 * ============================================
 */

import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Ribbon from "@/components/Ribbon";
import Approach from "@/components/Approach";
import Chart from "@/components/Chart";
import Philosophy from "@/components/Philosophy";
import Stats from "@/components/Stats";
import CTA from "@/components/CTA";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <>
      <Navbar />
      <Hero />
      <Ribbon />
      <Approach />
      <Chart />
      <Philosophy />
      <Stats />
      <CTA />
      <Footer />
    </>
  );
}
